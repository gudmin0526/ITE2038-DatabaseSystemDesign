select count(*)
from PlayableCharacter pc
where pc.class!='Explorer';