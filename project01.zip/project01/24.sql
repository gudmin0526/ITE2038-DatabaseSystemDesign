select rc.nickname
from User u
inner join Youtuber y on u.id=y.youtuber_id and y.country='Korea'
inner join RaisingCharacter rc on u.id=rc.owner_id
inner join PlayableCharacter pc on pc.id=rc.cid and pc.class='Explorer'
order by rc.nickname asc;