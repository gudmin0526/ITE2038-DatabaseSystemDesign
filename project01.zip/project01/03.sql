select distinct class 
from PlayableCharacter 
order by class asc;