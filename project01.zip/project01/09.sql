select nickname
from User u
inner join RaisingCharacter rc on u.id=rc.owner_id
where u.name='Chang' and rc.level=(
    select max(rc2.level)
    from RaisingCharacter rc2
    where rc2.owner_id=u.id
);