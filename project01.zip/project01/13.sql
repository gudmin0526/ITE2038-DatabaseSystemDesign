with CountsByOwner as (
    select u.id, count(*) as count
    from PlayableCharacter pc
    inner join RaisingCharacter rc on pc.branch='Warrior' and pc.id=rc.cid
    inner join User u on u.id=rc.owner_id
    group by u.id
)

select id, count
from CountsByOwner
where count=(
    select max(count)
    from CountsByOwner
);