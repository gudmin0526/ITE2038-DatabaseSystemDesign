select u.name
from Youtuber y
inner join Country c on y.country=c.name and c.continent="Asia"
inner join User u on u.id=y.youtuber_id;
