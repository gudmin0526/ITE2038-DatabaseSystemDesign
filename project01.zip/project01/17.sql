with MaxLevel as (
    select max(rc.level) as level
    from Youtuber y
    inner join RaisingCharacter rc on y.youtuber_id=rc.owner_id
    limit 1
)

select rc.nickname
from Youtuber y
inner join RaisingCharacter rc on y.youtuber_id=rc.owner_id
where rc.level=(
    select level
    from MaxLevel
);