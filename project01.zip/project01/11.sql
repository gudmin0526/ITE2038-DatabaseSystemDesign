select u.name, rc.nickname
from User u, RaisingCharacter rc
where u.id=rc.owner_id
  and rc.nickname like 'j%'
order by u.name asc;