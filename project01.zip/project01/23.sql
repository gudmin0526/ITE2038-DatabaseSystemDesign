select u.name as u_name, pc.name as pc_name
from User u
inner join RaisingCharacter rc on rc.owner_id=u.id
inner join PlayableCharacter pc on pc.id=rc.cid
order by u_name, pc_name asc;
