select distinct country
from User
order by country asc;