select distinct name
from PlayableCharacter
where class='Explorer'
order by name asc;