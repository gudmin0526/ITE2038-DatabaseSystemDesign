select distinct name
from User 
where country in ("UK", "Australia") 
order by name asc;