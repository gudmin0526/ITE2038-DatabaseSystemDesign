select avg(level)
from User u
inner join RaisingCharacter rc on u.id=rc.owner_id
inner join PlayableCharacter pc on pc.id=rc.cid and pc.class='Cygnus_Knights';