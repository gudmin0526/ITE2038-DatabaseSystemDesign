select u.name, sum(level) as sum_level
from Youtuber y
inner join User u on u.id=y.youtuber_id
inner join RaisingCharacter rc on rc.owner_id=u.id
group by u.id
order by sum_level desc;