select name
from PlayableCharacter
where class in ('Nova', 'Resistance') and branch='Warrior'
order by name asc;