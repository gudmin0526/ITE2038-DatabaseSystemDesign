with MaxCountOfUsersInCountry as (
    select count(country) as count
    from User
    group by country
    order by count desc
    limit 1
)

select country
from User
group by country
having count(country)=(
    select count
    from MaxCountOfUsersInCountry
);