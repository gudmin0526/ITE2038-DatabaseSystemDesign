with HighestAvgLevelByOwner as (
    select avg(level) as avg_level
    from User u
    inner join RaisingCharacter rc on u.id=rc.owner_id
    where u.country="USA"
    group by owner_id
    order by avg_level desc
    limit 1
)

select u.name
from User u
inner join RaisingCharacter rc on u.id=rc.owner_id
where u.country="USA"
group by owner_id
having avg(level)=(
    select avg_level
    from HighestAvgLevelByOwner
);