select distinct name
from Country
where name like 'U%'
order by name asc;
