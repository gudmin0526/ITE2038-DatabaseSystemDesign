select avg(level)
from RaisingCharacter;