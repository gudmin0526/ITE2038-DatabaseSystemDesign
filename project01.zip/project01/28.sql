select distinct name
from PlayableCharacter
where branch=(
    select branch
    from PlayableCharacter
    where name='Luminus'
)
order by name asc;