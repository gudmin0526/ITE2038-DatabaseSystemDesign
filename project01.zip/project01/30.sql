with RankOneUser as (
    select u.id, u.name
    from User u
    inner join RaisingCharacter rc on rc.owner_id=u.id
    where rc.level=(
        select max(level)
        from RaisingCharacter
    )
)

select level
from RaisingCharacter
where owner_id=(
    select id
    from RankOneUser
)
order by level asc
limit 1;