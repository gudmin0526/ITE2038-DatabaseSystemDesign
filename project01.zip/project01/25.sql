select distinct name
from PlayableCharacter
where name not in (
    select distinct pc.name
    from User u
    inner join RaisingCharacter rc on u.id=rc.owner_id
    inner join PlayableCharacter pc on pc.id=rc.cid
)
order by name asc;