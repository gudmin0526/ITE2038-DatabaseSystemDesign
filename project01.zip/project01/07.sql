select distinct name
from PlayableCharacter
where name like 'A%'
   or name like 'B%'
   or name like 'C%'
   or name like 'D%'
order by name asc;