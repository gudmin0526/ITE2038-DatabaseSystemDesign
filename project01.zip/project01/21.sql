select pc.name
from user u
inner join RaisingCharacter rc on u.id=rc.owner_id and u.country in ('Korea', 'UK')
inner join PlayableCharacter pc on rc.cid=pc.id
group by pc.name
having count(distinct u.country)=2
order by pc.name asc;