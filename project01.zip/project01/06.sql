select nickname
from RaisingCharacter
where level=(
    select max(level) 
    from RaisingCharacter
);