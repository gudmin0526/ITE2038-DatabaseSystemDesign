select distinct country
from User
where name not like 'J%'
order by country asc;