select max(level) as highest_level
from User u
inner join RaisingCharacter rc on u.id=rc.owner_id
group by u.country
order by highest_level desc;
