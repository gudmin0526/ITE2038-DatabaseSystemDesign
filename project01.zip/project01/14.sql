select branch
from PlayableCharacter
where id between 0 and 9
order by id desc;