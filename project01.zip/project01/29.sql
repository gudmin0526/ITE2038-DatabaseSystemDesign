with PreCondition as (
    select u.id, u.name, count(u.id) as count
    from User u
    inner join RaisingCharacter rc on u.id=rc.owner_id
    inner join PlayableCharacter pc on pc.id=rc.cid
    where pc.branch not in (
        select branch
        from PlayableCharacter
        where class='Resistance'
    )
    group by u.id
)

select distinct p1.name
from PreCondition p1
where p1.count=(
    select max(p2.count)
    from PreCondition p2
)
order by p1.name asc;